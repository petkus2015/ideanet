<?php
/**
 * Plugin Name:       Nadácia Anjelské krídla — bloky pre Avadu
 * Plugin URI:        https://nadaciaanjelskekridla.sk/
 * Description:       Hotové sekcie jednostránky nadácie pre Avada Builder vrátane správy log partnerov. Po importe sa objavia v Avada Library a v builderi ich vložíte cez Library → Containers.
 * Version:           1.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Nadácia Anjelské krídla
 * License:           GPL-2.0-or-later
 * Text Domain:       nadacia-bloky
 */

defined( 'ABSPATH' ) || exit;

define( 'AK_BLOKY_VERSION', '1.1.0' );
define( 'AK_BLOKY_FILE', __FILE__ );
define( 'AK_BLOKY_DIR', plugin_dir_path( __FILE__ ) );
define( 'AK_BLOKY_URL', plugin_dir_url( __FILE__ ) );

/**
 * Zoznam blokov. Kľúč = názov súboru v priečinku bloky/.
 */
function ak_bloky_zoznam() {
	return array(
		'01-hero'            => array( 'nazov' => 'Nadácia — 01 Hero (text + fotky 4:5)', 'popis' => 'Úvodný panel: vľavo text a tlačidlá, vpravo posuvač fotiek.' ),
		'02-cisla'           => array( 'nazov' => 'Nadácia — 02 Čísla',                   'popis' => 'Pás so štyrmi číslami (rok vzniku, dobrovoľníci, dotácie, 2 %).' ),
		'03-o-nas'           => array( 'nazov' => 'Nadácia — 03 O nás',                   'popis' => 'Fotka, text o nadácii a zoznam, komu pomáha.' ),
		'04-ako-pomahame'    => array( 'nazov' => 'Nadácia — 04 Ako pomáhame',            'popis' => 'Štyri karty so spôsobmi pomoci.' ),
		'05-ziadost-o-pomoc' => array( 'nazov' => 'Nadácia — 05 Žiadosť o pomoc',         'popis' => 'Postup v štyroch krokoch a tlačivá na stiahnutie.' ),
		'06-projekty'        => array( 'nazov' => 'Nadácia — 06 Projekty',                'popis' => 'Tri projekty s fotkou a odkazom.' ),
		'07-clanky'          => array( 'nazov' => 'Nadácia — 07 Články',                  'popis' => 'Náhľad posledných článkov (element Blog).' ),
		'08-galeria'         => array( 'nazov' => 'Nadácia — 08 Galéria',                 'popis' => 'Galéria s lightboxom.' ),
		'09-dve-percenta'    => array( 'nazov' => 'Nadácia — 09 Dve percentá z dane',     'popis' => 'Postup, údaje pre vyhlásenie a tlačivo na stiahnutie.' ),
		'10-podpora'         => array( 'nazov' => 'Nadácia — 10 Podporte nás',            'popis' => 'Tri spôsoby podpory vrátane čísla účtu.' ),
		'11-pribehy'         => array( 'nazov' => 'Nadácia — 11 Príbehy',                 'popis' => 'Ohlasy ľudí, ktorým nadácia pomohla.' ),
		'13-partneri'        => array( 'nazov' => 'Nadácia — 13 Partneri',               'popis' => 'Logá partnerov z nastavení pluginu; firma bez loga sa vypíše názvom. Patrí pred blok 12 Kontakt.' ),
		'12-kontakt'         => array( 'nazov' => 'Nadácia — 12 Kontakt',                 'popis' => 'Kontaktné údaje, siete a miesto na formulár.' ),
	);
}

/**
 * Načíta shortcode bloku a doplní adresy k obrázkom a dokumentom.
 */
function ak_bloky_obsah( $kluc ) {
	$subor = AK_BLOKY_DIR . 'bloky/' . $kluc . '.txt';
	if ( ! file_exists( $subor ) ) {
		return '';
	}
	$obsah  = file_get_contents( $subor ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	$uploads = wp_get_upload_dir();
	$ucet    = ak_bloky_ucet();

	return strtr(
		$obsah,
		array(
			'{{AK_IMG}}'  => AK_BLOKY_URL . 'assets/img/',
			'{{AK_DOC}}'  => trailingslashit( $uploads['baseurl'] ) . 'nadacia/',
			'{{AK_UCET}}'            => '' !== $ucet ? $ucet : '#podpora',
			'{{AK_UCET_IBAN}}'       => '' !== ak_bloky_ucet_iban() ? ak_bloky_ucet_iban() : 'SK.. .... .... .... .... ....',
			'{{AK_UCET_IBAN_PLAIN}}' => ak_bloky_ucet_iban_plain(),
		)
	);
}

/**
 * Odkaz na výpis transparentného účtu (prázdny, kým ho nevyplníte).
 */
function ak_bloky_ucet() {
	return (string) get_option( 'ak_bloky_ucet', '' );
}

/** Predvolený IBAN transparentného účtu nadácie. */
define( 'AK_BLOKY_UCET_IBAN', 'SK23 8330 0000 0027 0189 5491' );

/**
 * IBAN transparentného účtu tak, ako ho vypísať na stránke.
 * Predvyplnený je účet nadácie, v nastaveniach sa dá prepísať.
 */
function ak_bloky_ucet_iban() {
	return (string) get_option( 'ak_bloky_ucet_iban', AK_BLOKY_UCET_IBAN );
}

/**
 * IBAN bez medzier — to sa kopíruje do schránky.
 */
function ak_bloky_ucet_iban_plain() {
	return preg_replace( '/\s+/', '', ak_bloky_ucet_iban() );
}

/* ─────────────────────────────────────────────
   Partneri
   ───────────────────────────────────────────── */

/**
 * Zoznam partnerov: pole položiek s kľúčmi nazov, logo_id, url.
 */
function ak_bloky_partneri() {
	$partneri = get_option( 'ak_bloky_partneri', array() );
	return is_array( $partneri ) ? $partneri : array();
}

/**
 * Adresa loga partnera. Pri SVG vracia priamy odkaz na súbor.
 */
function ak_bloky_logo_url( $id ) {
	$id = (int) $id;
	if ( ! $id ) {
		return '';
	}
	$url = wp_get_attachment_image_url( $id, 'medium' );
	return $url ? $url : (string) wp_get_attachment_url( $id );
}

/**
 * Výpis partnerov — shortcode [nadacia_partneri].
 * Firma s logom sa vypíše obrázkom, bez loga názvom.
 */
function ak_bloky_partneri_shortcode() {
	$partneri = ak_bloky_partneri();
	if ( ! $partneri ) {
		return '';
	}

	$html = '<ul class="ak-partneri">';
	foreach ( $partneri as $partner ) {
		$nazov = isset( $partner['nazov'] ) ? (string) $partner['nazov'] : '';
		$odkaz = isset( $partner['url'] ) ? (string) $partner['url'] : '';
		$logo  = ak_bloky_logo_url( isset( $partner['logo_id'] ) ? $partner['logo_id'] : 0 );

		if ( '' === $nazov && '' === $logo ) {
			continue;
		}

		$obsah = '' !== $logo
			? '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( $nazov ) . '" loading="lazy" decoding="async">'
			: '<span class="ak-partner-nazov">' . esc_html( $nazov ) . '</span>';

		if ( '' !== $odkaz ) {
			$obsah = '<a href="' . esc_url( $odkaz ) . '" target="_blank" rel="noopener"'
				. ' aria-label="' . esc_attr( $nazov ) . '">' . $obsah . '</a>';
		}

		$html .= '<li class="ak-partner">' . $obsah . '</li>';
	}
	$html .= '</ul>';

	return $html;
}
add_shortcode( 'nadacia_partneri', 'ak_bloky_partneri_shortcode' );

/* ─────────────────────────────────────────────
   Štýly blokov
   ───────────────────────────────────────────── */
function ak_bloky_styly() {
	wp_enqueue_style(
		'nadacia-bloky',
		AK_BLOKY_URL . 'assets/css/nadacia-bloky.css',
		array(),
		AK_BLOKY_VERSION
	);
	wp_enqueue_script(
		'nadacia-bloky',
		AK_BLOKY_URL . 'assets/js/nadacia-bloky.js',
		array(),
		AK_BLOKY_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'ak_bloky_styly', 20 );
add_action( 'admin_enqueue_scripts', 'ak_bloky_styly_v_builderi' );

function ak_bloky_styly_v_builderi( $hook ) {
	// v editore stránok, aby náhľad v builderi sedel s webom
	if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		ak_bloky_styly();
	}
	// na našej stránke potrebujeme knižnicu médií na výber loga
	if ( 'toplevel_page_nadacia-bloky' === $hook ) {
		wp_enqueue_media();
		wp_enqueue_script(
			'nadacia-bloky-admin',
			AK_BLOKY_URL . 'assets/js/nadacia-bloky-admin.js',
			array( 'jquery' ),
			AK_BLOKY_VERSION,
			true
		);
	}
}

/* ─────────────────────────────────────────────
   Import do Avada Library
   ───────────────────────────────────────────── */

/** Je Avada Builder (Fusion Builder) aktívny? */
function ak_bloky_ma_avadu() {
	return post_type_exists( 'fusion_element' );
}

/**
 * Vytvorí alebo aktualizuje jeden blok v Avada Library.
 * Vracia ID príspevku alebo WP_Error.
 */
function ak_bloky_importuj_blok( $kluc ) {
	$zoznam = ak_bloky_zoznam();
	if ( ! isset( $zoznam[ $kluc ] ) ) {
		return new WP_Error( 'ak_neznamy_blok', 'Neznámy blok: ' . $kluc );
	}
	$obsah = ak_bloky_obsah( $kluc );
	if ( '' === $obsah ) {
		return new WP_Error( 'ak_prazdny_blok', 'Súbor bloku sa nenašiel: ' . $kluc );
	}

	$existujuci = ak_bloky_najdi_blok( $kluc );
	$data = array(
		'post_title'   => $zoznam[ $kluc ]['nazov'],
		'post_content' => $obsah,
		'post_status'  => 'publish',
		'post_type'    => 'fusion_element',
	);

	if ( $existujuci ) {
		$data['ID'] = $existujuci;
		$id = wp_update_post( $data, true );
	} else {
		$id = wp_insert_post( $data, true );
	}
	if ( is_wp_error( $id ) ) {
		return $id;
	}

	update_post_meta( $id, '_ak_blok', $kluc );
	update_post_meta( $id, '_fusion_element_type', 'sections' ); // v knižnici ide o kontajner/sekciu
	update_post_meta( $id, 'fusion_element_type', 'sections' );  // staršie verzie Avady
	update_post_meta( $id, '_fusion_builder_content', $obsah );

	return $id;
}

/** Nájde už naimportovaný blok podľa kľúča. */
function ak_bloky_najdi_blok( $kluc ) {
	$q = get_posts(
		array(
			'post_type'      => 'fusion_element',
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_ak_blok',   // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => $kluc,        // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	return $q ? (int) $q[0] : 0;
}

/* ─────────────────────────────────────────────
   Stránka v administrácii
   ───────────────────────────────────────────── */
function ak_bloky_menu() {
	add_menu_page(
		'Bloky nadácie',
		'Bloky nadácie',
		'manage_options',
		'nadacia-bloky',
		'ak_bloky_stranka',
		'dashicons-heart',
		59
	);
}
add_action( 'admin_menu', 'ak_bloky_menu' );

function ak_bloky_stranka() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Nemáte oprávnenie zobraziť túto stránku.', 'nadacia-bloky' ) );
	}

	$sprava = '';
	$chyba  = '';

	if ( isset( $_POST['ak_ulozit_partnerov'] ) && check_admin_referer( 'ak_bloky_partneri' ) ) {
		$novi   = array();
		$vstupy = isset( $_POST['partner'] ) ? (array) wp_unslash( $_POST['partner'] ) : array();

		foreach ( $vstupy as $riadok ) {
			if ( ! empty( $riadok['zmazat'] ) ) {
				continue;
			}
			$nazov   = isset( $riadok['nazov'] ) ? sanitize_text_field( $riadok['nazov'] ) : '';
			$logo_id = isset( $riadok['logo_id'] ) ? (int) $riadok['logo_id'] : 0;
			$url     = isset( $riadok['url'] ) ? esc_url_raw( $riadok['url'] ) : '';

			if ( '' === $nazov && ! $logo_id ) {
				continue;   // prázdny riadok preskočíme
			}
			$novi[] = array(
				'nazov'   => $nazov,
				'logo_id' => $logo_id,
				'url'     => $url,
			);
		}

		update_option( 'ak_bloky_partneri', $novi );
		$sprava = sprintf( 'Zoznam partnerov je uložený (%d).', count( $novi ) );
	}

	if ( isset( $_POST['ak_ulozit_ucet'] ) && check_admin_referer( 'ak_bloky_ucet' ) ) {
		$novy = isset( $_POST['ak_ucet'] ) ? esc_url_raw( wp_unslash( $_POST['ak_ucet'] ) ) : '';
		update_option( 'ak_bloky_ucet', $novy );

		$iban = isset( $_POST['ak_ucet_iban'] ) ? sanitize_text_field( wp_unslash( $_POST['ak_ucet_iban'] ) ) : '';
		$iban = strtoupper( preg_replace( '/[^A-Za-z0-9 ]/', '', $iban ) );
		update_option( 'ak_bloky_ucet_iban', trim( $iban ) );

		$sprava = 'Údaje transparentného účtu sú uložené.';
	}

	if ( isset( $_POST['ak_import'] ) && check_admin_referer( 'ak_bloky_import' ) ) {
		if ( ! ak_bloky_ma_avadu() ) {
			$chyba = 'Avada Builder nie je aktívny, knižnica sa nedá naplniť. Bloky si zatiaľ môžete skopírovať nižšie.';
		} else {
			$ok = 0;
			$zle = array();
			foreach ( array_keys( ak_bloky_zoznam() ) as $kluc ) {
				$vysledok = ak_bloky_importuj_blok( $kluc );
				if ( is_wp_error( $vysledok ) ) {
					$zle[] = $kluc;
				} else {
					$ok++;
				}
			}
			$sprava = sprintf( 'Do Avada Library sa uložilo %d blokov.', $ok );
			if ( $zle ) {
				$chyba = 'Nepodarilo sa: ' . implode( ', ', $zle );
			}
		}
	}
	?>
	<div class="wrap">
		<h1>Bloky nadácie pre Avada Builder</h1>

		<?php if ( $sprava ) : ?>
			<div class="notice notice-success"><p><?php echo esc_html( $sprava ); ?></p></div>
		<?php endif; ?>
		<?php if ( $chyba ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( $chyba ); ?></p></div>
		<?php endif; ?>
		<?php if ( ! ak_bloky_ma_avadu() ) : ?>
			<div class="notice notice-warning">
				<p>Nenašli sme Avada Builder. Aktivujte tému Avada aj plugin Avada Builder — až potom sa dajú bloky uložiť do knižnice.</p>
			</div>
		<?php endif; ?>

		<h2>1. Transparentný účet</h2>
		<p>Číslo účtu a odkaz na jeho výpis sa doplnia do bloku <strong>10 Podporte nás</strong> —
			IBAN aj s tlačidlom <em>Kopírovať IBAN</em> a odkaz do tlačidla
			<em>Transparentný účet — pozrieť pohyby</em>. Prázdne polia znamenajú naznačené miesto
			pre číslo a odkaz späť na sekciu podpory.</p>
		<form method="post">
			<?php wp_nonce_field( 'ak_bloky_ucet' ); ?>
			<p>
				<label for="ak_ucet_iban" style="display:block;font-weight:600">IBAN transparentného účtu</label>
				<input type="text" id="ak_ucet_iban" name="ak_ucet_iban" value="<?php echo esc_attr( ak_bloky_ucet_iban() ); ?>"
					class="regular-text" style="width:520px;max-width:100%"
					placeholder="<?php echo esc_attr( AK_BLOKY_UCET_IBAN ); ?>">
			</p>
			<p>
				<label for="ak_ucet" style="display:block;font-weight:600">Odkaz na výpis účtu</label>
				<input type="url" id="ak_ucet" name="ak_ucet" value="<?php echo esc_attr( ak_bloky_ucet() ); ?>"
					class="regular-text" style="width:520px;max-width:100%"
					placeholder="https://www.banka.sk/transparentne-ucty/SK12...">
			</p>
			<p><button type="submit" name="ak_ulozit_ucet" value="1" class="button">Uložiť údaje účtu</button></p>
		</form>
		<p class="description">Odkaz sa vkladá do blokov pri importe. Ak ho zmeníte neskôr, spustite import znova —
			prepíše sa tým položka v knižnici. V stránkach, kde už blok máte vložený, odkaz opravte priamo v builderi.</p>

		<h2>2. Partneri</h2>
		<p>Logá sa zobrazia v bloku <strong>13 Partneri</strong>. Nahrávajú sa cez knižnicu médií
			(PNG, JPG alebo SVG). Ak firma logo nemá, stačí vyplniť názov — vypíše sa textom.
			Zmeny sa na webe prejavia hneď po uložení, blok netreba znova importovať.</p>
		<form method="post" id="ak-partneri-form">
			<?php wp_nonce_field( 'ak_bloky_partneri' ); ?>
			<table class="widefat striped" id="ak-partneri-tabulka" style="max-width:900px">
				<thead>
					<tr>
						<th style="width:120px">Logo</th>
						<th>Názov firmy</th>
						<th style="width:260px">Odkaz na web (nepovinné)</th>
						<th style="width:90px">Zmazať</th>
					</tr>
				</thead>
				<tbody>
				<?php
				$partneri = ak_bloky_partneri();
				$partneri[] = array( 'nazov' => '', 'logo_id' => 0, 'url' => '' ); // prázdny riadok na pridanie
				foreach ( $partneri as $i => $partner ) :
					$logo_id  = isset( $partner['logo_id'] ) ? (int) $partner['logo_id'] : 0;
					$logo_url = ak_bloky_logo_url( $logo_id );
					?>
					<tr class="ak-partner-riadok">
						<td>
							<div class="ak-logo-nahlad" style="min-height:44px;display:flex;align-items:center">
								<?php if ( $logo_url ) : ?>
									<img src="<?php echo esc_url( $logo_url ); ?>" alt="" style="max-width:100px;max-height:44px">
								<?php else : ?>
									<span style="color:#787c82">bez loga</span>
								<?php endif; ?>
							</div>
							<input type="hidden" class="ak-logo-id" name="partner[<?php echo (int) $i; ?>][logo_id]" value="<?php echo (int) $logo_id; ?>">
							<p style="margin:6px 0 0">
								<button type="button" class="button button-small ak-vybrat-logo">Vybrať</button>
								<button type="button" class="button button-small ak-zmazat-logo" <?php disabled( ! $logo_id ); ?>>Odobrať</button>
							</p>
						</td>
						<td><input type="text" class="regular-text" name="partner[<?php echo (int) $i; ?>][nazov]"
							value="<?php echo esc_attr( isset( $partner['nazov'] ) ? $partner['nazov'] : '' ); ?>"
							placeholder="Napríklad Stavebniny Považie"></td>
						<td><input type="url" class="regular-text" name="partner[<?php echo (int) $i; ?>][url]"
							value="<?php echo esc_attr( isset( $partner['url'] ) ? $partner['url'] : '' ); ?>"
							placeholder="https://"></td>
						<td style="text-align:center">
							<label><input type="checkbox" name="partner[<?php echo (int) $i; ?>][zmazat]" value="1"> áno</label>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p>
				<button type="button" class="button" id="ak-pridat-partnera">Pridať ďalší riadok</button>
				<button type="submit" name="ak_ulozit_partnerov" value="1" class="button button-primary">Uložiť partnerov</button>
			</p>
			<p class="description">SVG WordPress štandardne nahrávať nedovolí. Ak ho potrebujete, doplňte plugin
				na bezpečné povolenie SVG, prípadne použite PNG s priehľadným pozadím.</p>
		</form>

		<h2>3. Import do knižnice</h2>
		<p>Tlačidlo uloží všetkých dvanásť sekcií do <strong>Avada → Library</strong>. Import môžete spustiť aj opakovane — bloky sa prepíšu, nevzniknú duplikáty.</p>
		<form method="post">
			<?php wp_nonce_field( 'ak_bloky_import' ); ?>
			<p><button type="submit" name="ak_import" value="1" class="button button-primary">Importovať bloky do Avada Library</button></p>
		</form>

		<h2>4. Vloženie do stránky</h2>
		<ol>
			<li>Stránky → Pridať novú, zapnite <strong>Avada Builder</strong>.</li>
			<li>Kliknite na <strong>Library</strong> (ikona knižnice v hornej lište buildera) a v záložke <em>Containers</em> vyberte blok.</li>
			<li>Blok sa vloží ako bežné kontajnery a stĺpce — ďalej ho upravujete klikaním.</li>
			<li>Poradie sekcií podľa návrhu: 01 → 12.</li>
		</ol>
		<p>Ak by sa bloky v knižnici nezobrazili, použite náhradnú cestu: skopírujte shortcode nižšie, v editore stránky prepnite <em>Toggle Builder</em> na klasický editor, vložte a prepnite späť.</p>

		<h2>5. Farby menu a témy</h2>
		<p>Bloky majú farby nastavené v sebe, hlavičku a menu však ovláda téma:</p>
		<ul style="list-style:disc;margin-left:22px">
			<li><strong>Avada → Options → Header</strong>: Header Background Color <code>#28afc3</code>.</li>
			<li><strong>Avada → Options → Menu → Main Menu</strong>: farba písma aj pri prejdení myšou <code>#ffffff</code>, pozadie rozbaľovacieho menu <code>#28afc3</code>.</li>
			<li><strong>Avada → Options → Menu → Mobile Menu</strong>: pozadie <code>#28afc3</code>, text <code>#ffffff</code>.</li>
			<li><strong>Avada → Options → Colors</strong>: Primary <code>#28afc3</code>, Text <code>#2a4750</code>, Headings <code>#0a1f26</code>, Link <code>#14707f</code>.</li>
		</ul>

		<h2>6. Čo doplniť</h2>
		<ul style="list-style:disc;margin-left:22px">
			<li>Fotky sú zatiaľ ilustračné a nesie ich tento plugin. Nahraďte ich vlastnými priamo v builderi (klik na obrázok → Select Image).</li>
			<li>Tlačivá na stiahnutie plugin neobsahuje. Nahrajte do knižnice médií súbory <code>ziadost-o-prispevok.pdf</code>, <code>suhlas-ochrana-osobnych-udajov.pdf</code> a <code>vyhlasenie-2-percenta.pdf</code> a v blokoch 05 a 09 opravte odkazy tlačidiel.</li>
			<li>Kontaktný formulár si vytvorte v <strong>Avada → Forms</strong> a vložte ho do pravého stĺpca bloku 12.</li>
			<li>Odkazy na sociálne siete v bloku 12 vedú zatiaľ na domovské stránky sietí.</li>
			<li>Ohlasy v bloku 11 sú ilustračné — nahraďte ich skutočnými so súhlasom rodín.</li>
		</ul>

		<h2>7. Bloky na skopírovanie</h2>
		<?php foreach ( ak_bloky_zoznam() as $kluc => $blok ) : ?>
			<?php $id = ak_bloky_najdi_blok( $kluc ); ?>
			<h3 style="margin-bottom:4px">
				<?php echo esc_html( $blok['nazov'] ); ?>
				<?php if ( $id ) : ?>
					<span style="font-weight:400;color:#1a7f37">— v knižnici</span>
				<?php endif; ?>
			</h3>
			<p style="margin:0 0 6px;color:#555"><?php echo esc_html( $blok['popis'] ); ?></p>
			<textarea readonly rows="3" style="width:100%;font-family:monospace;font-size:11px" onclick="this.select()"><?php echo esc_textarea( ak_bloky_obsah( $kluc ) ); ?></textarea>
		<?php endforeach; ?>
	</div>
	<?php
}

/* ─────────────────────────────────────────────
   Aktivácia
   ───────────────────────────────────────────── */
function ak_bloky_aktivacia() {
	// Import spúšťame až na požiadanie — pri aktivácii nemusí byť Avada ešte pripravená.
	add_option( 'ak_bloky_verzia', AK_BLOKY_VERSION );
}
register_activation_hook( __FILE__, 'ak_bloky_aktivacia' );

/** Odkaz na nastavenia v zozname pluginov. */
function ak_bloky_odkaz( $odkazy ) {
	$odkaz = '<a href="' . esc_url( admin_url( 'admin.php?page=nadacia-bloky' ) ) . '">Bloky</a>';
	array_unshift( $odkazy, $odkaz );
	return $odkazy;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'ak_bloky_odkaz' );
