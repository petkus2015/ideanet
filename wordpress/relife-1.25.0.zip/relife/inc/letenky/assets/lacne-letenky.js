/*!
 * Lacné letenky – plugin s najlacnejšími letenkami z Viedne a Bratislavy kamkoľvek.
 * Dáta: data/deals.json (aktualizuje GitHub Actions 3× denne z momondo.co.uk).
 *
 * Vloženie na stránku:
 *   <link rel="stylesheet" href="plugins/lacne-letenky/lacne-letenky.css">
 *   <div data-lacne-letenky data-src="plugins/lacne-letenky/data/deals.json"></div>
 *   <script src="plugins/lacne-letenky/lacne-letenky.js" defer></script>
 *
 * Alebo ručne: LacneLetenky.mount(element, { src: '…/deals.json', limit: 8 })
 *
 * Blok ukazuje iba ponuky z poslednej úspešnej aktualizácie – nikdy nie vymyslené ceny.
 */
(function () {
  'use strict';

  var FONTS = 'https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700' +
    '&family=JetBrains+Mono:wght@500;600&display=swap';
  var ARROW = '<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10h12M11 5l5 5-5 5"/></svg>';
  var CHEVRON = '<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8l5 5 5-5"/></svg>';
  var PLANE = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="M21.5 15.5v-2l-8-5V3.2c0-.9-.7-1.7-1.5-1.7s-1.5.8-1.5 1.7v5.3l-8 5v2l8-2.5v5.2l-2 1.5V21l3.5-1 3.5 1v-1.3l-2-1.5V13l8 2.5z" transform="rotate(90 12 12)"/></svg>';
  var CAL = '<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><rect x="3" y="4.5" width="14" height="12.5" rx="2.5"/><path d="M3 8.5h14M7 2.5v4M13 2.5v4"/></svg>';

  // Počasie v destinácii v deň príletu (Open-Meteo): ikony podľa typu počasia
  var WX_SUN = '<circle cx="12" cy="12" r="4.2" fill="#f5b301" stroke="none"/><g stroke="#f5b301"><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.5 1.5M17.2 17.2l1.5 1.5M5.3 18.7l1.5-1.5M17.2 6.8l1.5-1.5"/></g>';
  var WX_CLOUD = '<path d="M7.5 19h9.3a4 4 0 0 0 .5-8 5.5 5.5 0 0 0-10.6 1.3A3.4 3.4 0 0 0 7.5 19z" fill="#e3e8ef" stroke="#8a97a8"/>';
  var WX = {
    sun: { label: 'slnečno', svg: WX_SUN },
    partly: { label: 'polooblačno', svg: '<g transform="translate(-3 -3) scale(.8)">' + WX_SUN + '</g><path d="M9 20h8.3a3.6 3.6 0 0 0 .4-7.2 5 5 0 0 0-9.6 1.2A3 3 0 0 0 9 20z" fill="#e3e8ef" stroke="#8a97a8"/>' },
    cloud: { label: 'oblačno', svg: WX_CLOUD },
    fog: { label: 'hmla', svg: '<g stroke="#8a97a8"><path d="M4 9h16M6 13h12M4 17h16"/></g>' },
    rain: { label: 'dážď', svg: '<path d="M7.5 15h9.3a4 4 0 0 0 .5-8 5.5 5.5 0 0 0-10.6 1.3A3.4 3.4 0 0 0 7.5 15z" fill="#e3e8ef" stroke="#8a97a8"/><g stroke="#2f7de1"><path d="M8.5 18l-1 2.5M12.5 18l-1 2.5M16.5 18l-1 2.5"/></g>' },
    snow: { label: 'sneh', svg: '<path d="M7.5 15h9.3a4 4 0 0 0 .5-8 5.5 5.5 0 0 0-10.6 1.3A3.4 3.4 0 0 0 7.5 15z" fill="#e3e8ef" stroke="#8a97a8"/><g fill="#6aa9f0" stroke="none"><circle cx="8.5" cy="19" r="1.2"/><circle cx="12.5" cy="20.5" r="1.2"/><circle cx="16.5" cy="19" r="1.2"/></g>' },
    storm: { label: 'búrky', svg: '<path d="M7.5 15h9.3a4 4 0 0 0 .5-8 5.5 5.5 0 0 0-10.6 1.3A3.4 3.4 0 0 0 7.5 15z" fill="#d5dbe4" stroke="#6b7789"/><path d="M12.5 15l-2.5 4h3l-2 3.5" fill="none" stroke="#f5b301"/>' }
  };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function money(v, cur) {
    try {
      return new Intl.NumberFormat('sk-SK', { style: 'currency', currency: cur || 'EUR', currencyDisplay: 'narrowSymbol', maximumFractionDigits: 0 }).format(v);
    } catch (e) { return v + ' ' + (cur || ''); }
  }
  function day(iso) {
    if (!iso) return '';
    return new Date(iso + 'T12:00:00').toLocaleDateString('sk-SK', { weekday: 'short', day: 'numeric', month: 'short' });
  }
  function time(iso) {
    return new Date(iso).toLocaleTimeString('sk-SK', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Vienna' });
  }
  function relDay(iso) {
    var d = new Date(iso), now = new Date();
    var fmt = function (x) { return x.toLocaleDateString('sv-SE', { timeZone: 'Europe/Vienna' }); };
    if (fmt(d) === fmt(now)) return 'dnes';
    if (fmt(d) === fmt(new Date(now.getTime() - 864e5))) return 'včera';
    if (fmt(d) === fmt(new Date(now.getTime() + 864e5))) return 'zajtra';
    return d.toLocaleDateString('sk-SK', { day: 'numeric', month: 'short', timeZone: 'Europe/Vienna' });
  }
  function nights(n) {
    if (n == null) return 'jednosmerne';
    if (n === 1) return '1 noc';
    if (n >= 2 && n <= 4) return n + ' noci';
    return n + ' nocí';
  }
  function stopsLabel(s) {
    if (s == null) return '';
    if (s === 0) return 'Priamy let';
    if (s === 1) return '1 prestup';
    return s + ' prestupy';
  }
  function ensureFonts() {
    if (document.querySelector('link[data-ll-fonts]')) return;
    var l = document.createElement('link');
    l.rel = 'stylesheet'; l.href = FONTS; l.setAttribute('data-ll-fonts', '');
    document.head.appendChild(l);
  }

  var SOURCES = { momondo: 'momondo', ryanair: 'Ryanair', wizzair: 'Wizz Air' };
  function sourceName(d) { return SOURCES[d.source] || 'momondo'; }
  var REFRESH = '<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16.5 10a6.5 6.5 0 1 1-1.9-4.6M16.5 3.5v3.5H13"/></svg>';
  // Ponuky staršie ako toto sa už nezobrazia (aktualizácia zlyhala viackrát po sebe).
  var MAX_AGE_H = 36;
  var LIST_PREVIEW = 3; // koľko riadkov zoznamu Ázia a SAE je vidno pred rozbalením
  var listSeq = 0;
  // Hľadáme lety s odletom najviac 3 mesiace dopredu (rovnako ako scripts/update_deals.py).
  var HORIZON_DAYS = 92;

  function viennaDate(offsetDays) {
    return new Date(Date.now() + (offsetDays || 0) * 864e5).toLocaleDateString('sv-SE', { timeZone: 'Europe/Vienna' });
  }
  function isFresh(data) {
    return !!data.updatedAt && (Date.now() - new Date(data.updatedAt).getTime()) / 36e5 <= MAX_AGE_H;
  }
  function inWindow(d) {
    return !!d.depart && d.depart > viennaDate(0) && d.depart <= viennaDate(HORIZON_DAYS);
  }
  function freshDeals(data) {
    if (!isFresh(data)) return [];
    return (data.deals || []).filter(inWindow).sort(function (a, b) { return a.price - b.price; });
  }

  // Načíta dáta. fresh=true obíde cache prehliadača, aby tlačidlo vždy dostalo najnovší deals.json.
  function loadData(opts, fresh) {
    if (fresh && opts.src) {
      // refresh=1: WordPress plugin spustí živé hľadanie (momondo + Ryanair); statický deals.json ho ignoruje
      var url = opts.src + (opts.src.indexOf('?') > -1 ? '&' : '?') + 'refresh=1&t=' + Date.now();
      return fetch(url, { cache: 'no-store' }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      });
    }
    if (opts.data) return Promise.resolve(opts.data);
    if (window.LACNE_LETENKY_DATA) return Promise.resolve(window.LACNE_LETENKY_DATA);
    return fetch(opts.src || 'data/deals.json', { cache: 'no-cache' }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  function mount(el, opts) {
    opts = opts || {};
    if (opts.fonts !== false) ensureFonts();
    el.classList.add('ll');
    el.setAttribute('role', 'region');
    el.setAttribute('aria-label', 'Lacné letenky z Viedne a Bratislavy');

    el.innerHTML = '<div class="ll-grid"><div class="ll-skel"></div><div class="ll-skel"></div><div class="ll-skel"></div><div class="ll-skel"></div></div>';
    return loadData(opts, false).then(function (data) {
      render(el, data, opts, '');
      // aktuálne ceny pri každom otvorení stránky (WordPress: živé hľadanie, výsledok platí pár minút)
      if (opts.autoRefresh && opts.src) search(el, data, opts, true);
    }, function (err) {
      el.innerHTML = '<div class="ll-empty"><p>Letenky sa nepodarilo načítať (' + esc(err.message) +
        '). Skontrolujte cestu k súboru deals.json v atribúte data-src.</p></div>';
    });
  }

  // Partnerské odkazy: šablóna odkazu pre každú spoločnosť (momondo, ryanair, wizzair, pegasus, default).
  // Šablóna obaľuje pôvodný odkaz na let: {url} alebo {url_enc} (zakódovaný), ďalej {origin}, {dest},
  // {depart}, {return}, {source}. Bez šablóny sa použije pôvodný odkaz.
  function affiliateFor(opts, d) {
    var a = opts.affiliate || {};
    var tpl = a[d.source] || a['default'] || '';
    if (!tpl || !d.url) return null;
    var vars = { url: d.url, url_enc: encodeURIComponent(d.url), origin: d.origin, dest: d.dest,
      depart: d.depart || '', 'return': d['return'] || '', source: d.source || '' };
    return tpl.replace(/\{(\w+)\}/g, function (m, k) { return vars.hasOwnProperty(k) ? vars[k] : m; });
  }
  function hasAffiliate(opts) {
    var a = opts.affiliate || {};
    return Object.keys(a).some(function (k) { return !!a[k]; });
  }

  function render(el, data, opts, note) {
    var fresh = isFresh(data);
    // Bangkok (a ďalšie sledované mestá): iba spiatočná letenka v najbližších 3 mesiacoch.
    var watch = (data.watch || []).map(function (w) {
      var d = w.deal;
      return {
        name: w.name, airports: w.airports || [], searchUrl: w.searchUrl, featured: w.featured === true || (w.featured == null && w.name === 'Bangkok'), list: w.list === true, note: w.note,
        deal: fresh && d && d['return'] && inWindow(d) ? d : null
      };
    });
    // featured (Bangkok) = veľká karta; list (Ázia, SAE) = zoznam pod ňou;
    // ostatné sledované mestá sa vždy pridajú medzi karty
    // v zozname iba destinácie, do ktorých som našiel spiatočnú letenku
    var listed = watch.filter(function (w) { return !w.featured && w.list && w.deal; });
    var listId = el.getAttribute('data-ll-list') || 'll-list-' + (++listSeq);
    el.setAttribute('data-ll-list', listId);
    var pinned = watch.filter(function (w) { return !w.featured && !w.list; });
    var pinnedDeals = pinned.filter(function (w) { return w.deal; })
      .map(function (w) {
        var d = {}; for (var k in w.deal) d[k] = w.deal[k];
        d.city = w.name; // jedno letisko = názov destinácie (Malta, Alicante, Catania)
        return d;
      });
    watch = watch.filter(function (w) { return w.featured && w.deal; });
    // sledované mesto (Bangkok) má vlastnú kartu, jeho letiská sa v mriežke neopakujú
    var watched = {};
    (data.watch || []).forEach(function (w) { (w.airports || []).forEach(function (a) { watched[a] = 1; }); });
    var limit = opts.limit || 8;
    // výber pod ponukami: všetky / Európa / mimo Európy
    var region = opts.region || 'all';
    var inRegion = function (d) {
      return region === 'all' || (region === 'eu' ? d.region === 'Európa' : d.region !== 'Európa');
    };
    var pinnedIn = pinnedDeals.filter(inRegion);
    var allDeals = freshDeals(data);
    // odkiaľ (Viedeň / Bratislava / Budapešť) a zoradenie platia pre víkendové aj dlhšie pobyty
    var origin = opts.origin || 'all';
    var sortBy = opts.sort === 'date' ? 'date' : 'price';
    var fromOrigin = function (d) { return origin === 'all' || d.origin === origin; };
    var order = function (a, b) {
      return sortBy === 'date' ? (a.depart < b.depart ? -1 : a.depart > b.depart ? 1 : a.price - b.price) : a.price - b.price;
    };
    var deals = allDeals.filter(function (d) { return !watched[d.dest] && inRegion(d) && fromOrigin(d); })
      .slice(0, limit)           // najlacnejšie ponuky…
      .concat(pinnedIn.filter(fromOrigin))   // …a k nim vždy sledované letiská (Alicante, Sicília, Malta)
      .sort(order);
    var cities = {};
    (data.origins || []).forEach(function (o) { cities[o.code] = o.from || o.city; });
    // predĺžený víkend: odlet štvrtok/piatok, návrat nedeľa/pondelok (zostavuje scripts/update_deals.py)
    var weekendDeals = fresh
      ? (data.weekend || []).filter(function (d) { return d['return'] && inWindow(d) && fromOrigin(d); })
          .sort(function (a, b) { return a.price - b.price; }).slice(0, Math.max(limit, 8)).sort(order)
      : [];

    function datesText(d) {
      return esc(day(d.depart)) + (d['return'] ? ' – ' + esc(day(d['return'])) : '') + ' · ' + nights(d.nights);
    }
    // „☀ 31 °C“ – predpoveď na deň príletu, pri vzdialenejšom termíne odhad z minulých rokov
    function wxHtml(d) {
      var w = d.weather;
      if (!w || w.t == null) return '';
      var k = WX[w.c] || WX.cloud;
      var when = day(d.depart);
      var tip = (w.k === 'f' ? 'Predpoveď počasia' : 'Odhad počasia podľa minulých rokov') + ' – ' + d.city + ', ' + when + ': ' + k.label + ', cez deň okolo ' + w.t + ' °C';
      return '<span class="ll-wx' + (w.k === 'f' ? '' : ' is-est') + '" title="' + esc(tip) + '" aria-label="' + esc(tip) + '">' +
        '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + k.svg + '</svg>' +
        '<span>' + (w.k === 'f' ? '' : '~') + w.t + ' °C</span></span>';
    }

    // Zmena ceny oproti predchádzajúcemu hľadaniu – iba pri tom istom lete (letiská aj dátumy).
    function changeHtml(d, long) {
      if (!d.prevPrice || d.prevPrice === d.price) return '';
      var diff = Math.abs(d.prevPrice - d.price), down = d.prevPrice > d.price;
      var when = data.prevUpdatedAt ? ' (' + relDay(data.prevUpdatedAt) + ' ' + time(data.prevUpdatedAt) + ')' : '';
      var tip = 'Pri predchádzajúcom hľadaní' + when + ' stál tento let ' + money(d.prevPrice, d.currency) + '.';
      return '<span class="ll-change ' + (down ? 'is-down' : 'is-up') + '" title="' + esc(tip) + '">' +
        (down ? '▼ o ' : '▲ o ') + money(diff, d.currency) + (down ? ' lacnejšie' : ' drahšie') +
        (long ? ' od posledného hľadania' : '') + '</span>';
    }

    // href + rel odkazu na let; pri partnerskom odkaze rel="sponsored nofollow" (pravidlá Google)
    function linkAttrs(d) {
      var aff = affiliateFor(opts, d);
      return 'href="' + esc(aff || d.url) + '" target="_blank" rel="' + (aff ? 'sponsored nofollow noopener' : 'noopener') + '"';
    }

    function cardHtml(d, best) {
      var from = cities[d.origin] || d.origin;
      var drop = changeHtml(d, false);
      return '<li><a class="ll-card" ' + linkAttrs(d) + ' aria-label="' +
          esc(d.city + ', ' + d.country + ', let z ' + from + ' od ' + money(d.price, d.currency) + '. Otvoriť na ' + sourceName(d)) + '">' +
        '<div class="ll-card-top"><span class="ll-card-id"><span class="ll-route">' + esc(d.origin) + ' ' + PLANE + ' ' + esc(d.dest) + '</span>' +
          '</span>' +
          (stopsLabel(d.stops) ? '<span class="ll-chip">' + stopsLabel(d.stops) + '</span>' : '') + '</div>' +
        '<div><div class="ll-city-row"><p class="ll-city">' + esc(d.city) + '</p>' + wxHtml(d) + '</div><p class="ll-country">' + esc(d.country) + ' · z ' + esc(from) + '</p></div>' +
        '<p class="ll-dates">' + CAL + '<span>' + datesText(d) + '</span></p>' +
        '<div class="ll-card-bottom"><div class="ll-price"><span class="ll-price-label"><small>' + (d['return'] ? 'spiatočná od' : 'od') + '</small>' + drop + (best && !drop ? '<span class="ll-best">Najlacnejšie</span>' : '') + '</span>' +
          '<strong>' + money(d.price, d.currency) + '</strong>' +
          '<span class="ll-source" data-src="' + esc(d.source || 'momondo') + '">cez ' + esc(sourceName(d)) + '</span></div>' +
          '<span class="ll-go" aria-hidden="true">' + ARROW + '</span></div>' +
      '</a></li>';
    }

    function watchHtml(w) {
      var d = w.deal;
      if (!d) {
        return '<div class="ll-watch-empty"><span><b>' + esc(w.name) + '</b> – v najbližších 3 mesiacoch som pri poslednom hľadaní nenašiel spiatočnú letenku.</span>' +
          '<a class="ll-more" href="' + esc(w.searchUrl) + '" target="_blank" rel="noopener">Pozrieť na momondo →</a></div>';
      }
      var from = cities[d.origin] || d.origin;
      var drop = changeHtml(d, true);
      return '<a class="ll-feature" ' + linkAttrs(d) + ' aria-label="' +
          esc(w.name + ', spiatočná letenka z ' + from + ' od ' + money(d.price, d.currency) + '. Otvoriť na ' + sourceName(d)) + '">' +
        '<svg class="ll-feature-arc" viewBox="0 0 400 200" preserveAspectRatio="none" aria-hidden="true"><path d="M10 190 C 120 20, 290 10, 390 70"/></svg>' +
        '<div class="ll-feature-main">' +
          '<p class="ll-feature-kicker">Najlacnejšia spiatočná do ' + esc(w.name === 'Bangkok' ? 'Bangkoku' : w.name) + '</p>' +
          '<p class="ll-feature-city">' + esc(w.name) + '</p>' +
          '<p class="ll-feature-meta"><span class="ll-route">' + esc(d.origin) + ' ' + PLANE + ' ' + esc(d.dest) + '</span>' +
            '<span>z ' + esc(from) + '</span>' + (stopsLabel(d.stops) ? '<span>' + stopsLabel(d.stops) + '</span>' : '') + '</p>' +
          '<p class="ll-feature-meta">' + CAL + '<span>' + datesText(d) + '</span>' + wxHtml(d) + '</p>' +
        '</div>' +
        '<div class="ll-feature-side">' +
          '<small>spiatočná od</small>' +
          '<strong>' + money(d.price, d.currency) + '</strong>' + drop +
          '<span class="ll-feature-cta">Kúpiť ' + ARROW + '</span>' +
        '</div></a>';
    }

    // posuvný pás kariet so šípkami (hlavný aj víkendový)
    function railHtml(list, label) {
      return '<div class="ll-rail">' +
          '<ul class="ll-grid" tabindex="0" aria-label="' + esc(label) + '">' + list.map(function (d, i) { return cardHtml(d, i === 0 && sortBy === 'price' && list.length > 1); }).join('') + '</ul>' +
          '<div class="ll-navbar">' +
            '<button type="button" class="ll-nav" data-nav="-1" aria-label="Predchádzajúce ponuky" disabled>' + ARROW + '</button>' +
            '<button type="button" class="ll-nav" data-nav="1" aria-label="Ďalšie ponuky">' + ARROW + '</button>' +
          '</div>' +
        '</div>';
    }

    function countHtml(n) {
      return n ? '<span class="ll-count">' + n + (n === 1 ? ' ponuka' : n < 5 ? ' ponuky' : ' ponúk') + '</span>' : '';
    }

    // Panel nad ponukami: odkiaľ letím, zoradenie a kedy som ceny vyhľadal
    function toolbarHtml() {
      var counts = {};
      (data.weekend || []).concat(allDeals).forEach(function (d) { counts[d.origin] = (counts[d.origin] || 0) + 1; });
      var origins = [['all', 'Všetky letiská']].concat((data.origins || []).filter(function (o) { return counts[o.code]; })
        .map(function (o) { return [o.code, o.city || o.code]; }));
      if (origins.length < 3 && !fresh) return '';
      return '<div class="ll-toolbar">' +
        '<div class="ll-bar"><span class="ll-bar-label" id="' + listId + '-o">Odlet z</span>' +
          '<div class="ll-chips" role="group" aria-labelledby="' + listId + '-o">' + origins.map(function (o) {
            return '<button type="button" data-origin="' + esc(o[0]) + '" aria-pressed="' + (origin === o[0]) + '">' + esc(o[1]) + '</button>';
          }).join('') + '</div></div>' +
        '<div class="ll-bar"><span class="ll-bar-label" id="' + listId + '-s">Zoradiť</span>' +
          '<div class="ll-chips" role="group" aria-labelledby="' + listId + '-s">' +
            '<button type="button" data-sort="price" aria-pressed="' + (sortBy === 'price') + '">Podľa ceny</button>' +
            '<button type="button" data-sort="date" aria-pressed="' + (sortBy === 'date') + '">Podľa termínu</button>' +
          '</div></div>' +
        (fresh ? '<span class="ll-fresh" title="Ceny vyhľadávam trikrát denne – o 7:00, 12:00 a 18:00."><i aria-hidden="true"></i>Vyhľadané ' + relDay(data.updatedAt) + ' ' + time(data.updatedAt) + '</span>' : '') +
      '</div>';
    }

    function weekendHtml() {
      if (!weekendDeals.length) return '';   // bez nájdenej letenky sekciu nezobrazujeme
      return '<section class="ll-sect ll-weekend" aria-label="Predĺžený víkend">' +
        '<div class="ll-sect-head"><div><h3 class="ll-sect-title">Na predĺžený víkend – najlacnejšie letenky</h3>' +
          '<p class="ll-sub">Odlet vo štvrtok alebo piatok, návrat v nedeľu alebo pondelok (3 až 4 noci).</p></div>' + countHtml(weekendDeals.length) + '</div>' +
        railHtml(weekendDeals, 'Lacné letenky na predĺžený víkend') + '</section>';
    }

    // Kategória 2: najlacnejšie letenky na dlhší pobyt (5–14 nocí) s odletom do 3 mesiacov
    function longHtml() {
      return '<section class="ll-sect ll-long" aria-label="Dlhší pobyt">' +
        '<div class="ll-sect-head"><div><h3 class="ll-sect-title">Najlacnejšie letenky na dlhší pobyt do 3 mesiacov</h3>' +
          '<p class="ll-sub">Odlet do 3 mesiacov, pobyt 5 až 14 nocí.</p></div>' + countHtml(deals.length) + '</div>' +
        (hasAny
          ? '<div class="ll-filter" role="group" aria-label="Oblasť">' + regions.map(function (r) {
              return '<button type="button" data-region="' + r[0] + '" aria-pressed="' + (region === r[0]) + '">' + r[1] + '</button>';
            }).join('') + '</div>'
          : '') +
        (deals.length
          ? railHtml(deals, 'Lacné letenky na dlhší pobyt')
          : hasAny
            ? '<div class="ll-empty"><b>Pre tento výber som teraz nenašiel ponuky</b><span>Skúste iné letisko, inú oblasť alebo nové hľadanie.</span></div>'
            : '<div class="ll-empty"><b>Práve nemáme aktuálne ponuky</b><span>Nové ceny pribudnú pri najbližšom hľadaní o 7:00, 12:00 alebo 18:00.</span></div>') +
        '</section>';
    }

    // Kategória 3: Ázia a Emiráty – veľká karta Bangkoku a zoznam krajín
    function asiaHtml() {
      var feature = watch.map(watchHtml).join('');
      var list = fresh ? listHtml() : '';
      if (!feature && !list) return '';
      return '<section class="ll-sect ll-asia" aria-label="Ázia a Emiráty">' +
        '<div><h3 class="ll-sect-title">Do Ázie a Emirátov – najlacnejšie letenky</h3>' +
          '<p class="ll-sub">Spiatočné letenky do Ázie a Spojených arabských emirátov, odlet do 3 mesiacov – vždy najlacnejšia zo všetkých troch letísk.</p></div>' +
        feature + list + '</section>';
    }

    function listHtml() {
      if (!listed.length) return '';
      var rows = listed.slice().sort(function (a, b) {
        return (a.deal ? a.deal.price : 1e9) - (b.deal ? b.deal.price : 1e9);
      }).map(function (w, i) {
        var d = w.deal;
        // zoznam je zbalený – ďalšie riadky sa ukážu po kliknutí na „Zobraziť všetky“
        var li = '<li' + (i >= LIST_PREVIEW && !opts.listOpen ? ' hidden' : '') + '>';
        if (!d) {
          return li + '<div class="ll-row is-empty">' +
            '<span class="ll-row-main"><b class="ll-row-name">' + esc(w.name) + '</b>' +
              '<span class="ll-row-sub">' + esc(w.note || '') + '</span></span>' +
            '<span class="ll-row-dates">Bez spiatočnej ponuky do 3 mesiacov</span>' +
            '<span class="ll-row-price"></span>' +
            '<a class="ll-row-go" href="' + esc(w.searchUrl) + '" target="_blank" rel="noopener">Hľadať ' + ARROW + '</a>' +
          '</div></li>';
        }
        var from = cities[d.origin] || d.originCity || d.origin;
        return li + '<a class="ll-row" ' + linkAttrs(d) + ' aria-label="' +
            esc(w.name + ', ' + d.city + ', spiatočná letenka z ' + from + ' od ' + money(d.price, d.currency) + '. Otvoriť na ' + sourceName(d)) + '">' +
          '<span class="ll-row-main"><span class="ll-row-head"><b class="ll-row-name">' + esc(w.name) + '</b>' + wxHtml(d) + '</span>' +
            '<span class="ll-row-sub">' + esc(d.city) + ' · <span class="ll-route">' + esc(d.origin) + ' ' + PLANE + ' ' + esc(d.dest) + '</span>' +
            (stopsLabel(d.stops) ? ' · ' + stopsLabel(d.stops) : '') +
            (d.originNote ? ' · <b class="ll-alt-origin">' + esc(d.originNote) + '</b>' : '') + '</span></span>' +
          '<span class="ll-row-dates">' + CAL + '<span>' + datesText(d) + '</span></span>' +
          '<span class="ll-row-price"><small>od</small><strong>' + money(d.price, d.currency) + '</strong>' + changeHtml(d, false) +
            '<em class="ll-source" data-src="' + esc(d.source || 'momondo') + '">cez ' + esc(sourceName(d)) + '</em></span>' +
          '<span class="ll-row-go">Kúpiť ' + ARROW + '</span>' +
        '</a></li>';
      }).join('');
      var more = listed.length - LIST_PREVIEW;
      return '<section class="ll-list-wrap" aria-label="Ázia a SAE">' +
        '<ul class="ll-list" id="' + listId + '">' + rows + '</ul>' +
        (more > 0
          ? '<button type="button" class="ll-list-toggle" data-list-toggle aria-controls="' + listId + '" aria-expanded="' + !!opts.listOpen + '">' +
              '<span>' + (opts.listOpen ? 'Zobraziť menej' : 'Zobraziť všetky (' + listed.length + ')') + '</span>' + CHEVRON + '</button>'
          : '') +
        '</section>';
    }

    var regions = [['all', 'Všetky'], ['eu', 'Európa'], ['world', 'Mimo Európy']];
    var hasAny = allDeals.length > 0;
    var hasWx = allDeals.concat(weekendDeals, watch.map(function (w) { return w.deal; }), listed.map(function (w) { return w.deal; }))
      .some(function (d) { return d && d.weather; });

    // Blok začína rovno ponukami; nadpis sa ukáže, len ak ho web zadá (data-title / Nadpis v nastaveniach).
    el.innerHTML =
      (opts.title ? '<h2 class="ll-title">' + esc(opts.title) + '</h2>' : '') +
      (hasAny || weekendDeals.length ? toolbarHtml() : '') +
      weekendHtml() +   // 1. predĺžený víkend
      longHtml() +      // 2. dlhší pobyt do 3 mesiacov
      asiaHtml() +      // 3. Ázia a Emiráty
      '<div class="ll-actions">' +
        '<button type="button" class="ll-refresh" data-refresh>' + REFRESH + '<span>Vyhľadaj aktuálne lacné letenky</span></button>' +
        '<p class="ll-msg" role="status" aria-live="polite"' + (note ? '' : ' hidden') + '>' + esc(note) + '</p>' +
      '</div>' +
      (hasAny
        ? '<p class="ll-foot">Porovnávam momondo.co.uk, ryanair.com a wizzair.com z Viedne, Bratislavy a Budapešti a ukazujem najnižšiu cenu za osobu v eurách' +
            (data.fx ? ', prepočítané kurzom ECB' + (data.fx.date ? ' z ' + esc(data.fx.date) : '') : '') +
            (fresh ? '. Hľadané ' + relDay(data.updatedAt) + ' ' + time(data.updatedAt) : '') +
            '. Ceny sa menia, pred nákupom ich overte.' +
            (hasAffiliate(opts) ? ' Odkazy na letenky sú partnerské: ak cez ne kúpite, môžem dostať províziu, cena sa pre vás nemení.' : '') +
            (hasWx ? ' Počasie v deň príletu: <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo.com</a> (predpoveď do 15 dní, ďalej odhad ~ z minulých rokov).' : '') +
            '</p>'
        : '');

    // rozbalenie / zbalenie zoznamu Ázia a SAE
    var toggle = el.querySelector('[data-list-toggle]');
    if (toggle) {
      toggle.addEventListener('click', function () {
        opts.listOpen = !opts.listOpen;
        Array.prototype.forEach.call(el.querySelectorAll('.ll-list > li'), function (li, i) {
          li.hidden = i >= LIST_PREVIEW && !opts.listOpen;
        });
        toggle.setAttribute('aria-expanded', String(opts.listOpen));
        toggle.firstChild.textContent = opts.listOpen ? 'Zobraziť menej' : 'Zobraziť všetky (' + listed.length + ')';
      });
    }

    // výber oblasti – prekreslí ponuky bez nového hľadania
    Array.prototype.forEach.call(el.querySelectorAll('[data-region]'), function (b) {
      b.addEventListener('click', function () {
        opts.region = b.getAttribute('data-region');
        render(el, data, opts, '');
        var again = el.querySelector('[data-region="' + opts.region + '"]');
        if (again) again.focus();
      });
    });

    // odkiaľ a zoradenie – prekreslí ponuky bez nového hľadania
    Array.prototype.forEach.call(el.querySelectorAll('[data-origin],[data-sort]'), function (b) {
      b.addEventListener('click', function () {
        var attr = b.hasAttribute('data-origin') ? 'origin' : 'sort';
        opts[attr] = b.getAttribute('data-' + attr);
        render(el, data, opts, '');
        var again = el.querySelector('[data-' + attr + '="' + opts[attr] + '"]');
        if (again) again.focus();
      });
    });

    // šípky posúvača (myš na počítači); prstom sa posúva priamo – pre každý pás zvlášť
    Array.prototype.forEach.call(el.querySelectorAll('.ll-rail'), function (rail) {
      var grid = rail.querySelector('.ll-grid');
      var navs = rail.querySelectorAll('[data-nav]');
      var navbar = rail.querySelector('.ll-navbar');
      var syncNav = function () {
        var max = grid.scrollWidth - grid.clientWidth - 2;
        navs[0].disabled = grid.scrollLeft <= 2;
        navs[1].disabled = grid.scrollLeft >= max;
        navbar.hidden = max <= 0; // všetko sa zmestí – šípky netreba
        rail.classList.toggle('is-end', max <= 0 || grid.scrollLeft >= max);
      };
      Array.prototype.forEach.call(navs, function (b) {
        b.addEventListener('click', function () {
          var card = grid.querySelector('li');
          var step = card ? card.getBoundingClientRect().width + parseFloat(getComputedStyle(grid).columnGap || 0) : grid.clientWidth / 1.5;
          grid.scrollBy({ left: step * +b.getAttribute('data-nav'), behavior: 'smooth' });
        });
      });
      grid.addEventListener('scroll', syncNav, { passive: true });
      syncNav();
    });

    var btn = el.querySelector('[data-refresh]');
    btn.addEventListener('click', function () { search(el, data, opts, false); });
  }

  // Nové hľadanie: po kliknutí na tlačidlo, alebo automaticky hneď po načítaní stránky (auto = true).
  // Pri automatickom hľadaní sa nič neruší – kým beží, blok ukazuje posledné známe ceny.
  function search(el, data, opts, auto, retry) {
    var btn = el.querySelector('[data-refresh]');
    if (!btn || btn.getAttribute('aria-busy') === 'true') return;
    btn.setAttribute('aria-busy', 'true');
    btn.querySelector('span').textContent = auto ? 'Načítavam aktuálne ceny…' : 'Hľadám najlacnejšie letenky…';
    var started = Date.now();
    var done = function (next, msg) {
      // krátke čakanie, aby hľadanie nepôsobilo ako bliknutie
      setTimeout(function () {
        var lefts = Array.prototype.map.call(el.querySelectorAll('.ll-grid'), function (g) { return g.scrollLeft; });
        render(el, next, opts, msg);
        Array.prototype.forEach.call(el.querySelectorAll('.ll-grid'), function (g, i) { if (lefts[i]) g.scrollLeft = lefts[i]; });
        var b = el.querySelector('[data-refresh]');
        if (b && !auto) b.focus();
      }, auto ? 0 : Math.max(0, 700 - (Date.now() - started)));
    };
    loadData(opts, true).then(function (next) {
      if (!next || !next.updatedAt) {
        done(next && next.updatedAt ? next : data, auto ? '' : 'Ponuky sa ešte pripravujú. Skúste to o chvíľu znova.');
        return;
      }
      // WordPress: výsledok živého hľadania
      if (next.liveBusy) {
        if (auto && !retry) {
          // hľadanie práve spustil iný návštevník – o chvíľu si vezmem jeho výsledok
          setTimeout(function () { btn.removeAttribute('aria-busy'); search(el, data, opts, true, true); }, 6000);
          return;
        }
        done(auto ? data : next, auto ? '' : 'Hľadanie práve prebieha pre iného návštevníka. Skúste to o pár sekúnd.');
        return;
      }
      if (next.liveError) {
        done(next, auto ? '' : 'Nové hľadanie sa teraz nepodarilo, zdroje neodpovedali. Zobrazujem ponuky z ' +
          relDay(next.updatedAt) + ' ' + time(next.updatedAt) + '. Skúste to o chvíľu znova.');
        return;
      }
      if (next.live) {
        done(next, next.liveAgeMin > 0
          ? 'Ponuky sú aktuálne – vyhľadal som ich pred ' + next.liveAgeMin + ' min (' + time(next.updatedAt) + ').'
          : 'Hotovo – najlacnejšie letenky som vyhľadal práve teraz (' + time(next.updatedAt) + ').');
        return;
      }
      if (auto) { done(next, ''); return; }
      var isNew = next.updatedAt && next.updatedAt !== data.updatedAt;
      var when = next.updatedAt ? relDay(next.updatedAt) + ' ' + time(next.updatedAt) : '';
      var nextRun = next.nextUpdate && new Date(next.nextUpdate) > new Date() ? ' Ďalšie hľadanie prebehne ' + relDay(next.nextUpdate) + ' o ' + time(next.nextUpdate) + '.' : '';
      done(next, isNew ? 'Našiel som nové ponuky z hľadania ' + when + '.' : 'Máte najnovšie ponuky z hľadania ' + when + '.' + nextRun);
    }, function () {
      done(data, auto ? '' : 'Nové ponuky sa teraz nepodarilo načítať, zobrazujem posledné známe. Skúste to o chvíľu znova.');
    });
  }

  function auto() {
    document.querySelectorAll('[data-lacne-letenky]').forEach(function (el) {
      if (el.__ll) return;
      el.__ll = true;
      // WordPress plugin vkladá počiatočné dáta priamo do stránky – blok sa ukáže bez čakania
      var initial = null, init = el.querySelector('script[data-ll-initial]');
      if (init) { try { initial = JSON.parse(init.textContent); } catch (e) { initial = null; } }
      if (el.getAttribute('data-font') === 'inherit') el.classList.add('ll-inherit-font');
      mount(el, {
        data: initial || undefined,
        src: el.getAttribute('data-src') || undefined,
        limit: +el.getAttribute('data-limit') || 0,
        title: el.getAttribute('data-title') || undefined,
        affiliate: (function () { try { return JSON.parse(el.getAttribute('data-affiliate') || '') || undefined; } catch (e) { return undefined; } })(),
        fonts: el.getAttribute('data-fonts') !== 'false',
        autoRefresh: el.hasAttribute('data-autoload')
      });
    });
  }

  window.LacneLetenky = { mount: mount };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', auto);
  else auto();
})();
