<?php
/**
 * Nastavenia → Lacné letenky: zdroj dát, cache, počet kariet, písmo a stav posledného načítania.
 */

defined( 'ABSPATH' ) || exit;

class Lacne_Letenky_Settings {

	const OPTION = 'lacne_letenky_options';

	public static function defaults() {
		return array(
			'src'           => LACNE_LETENKY_DEFAULT_SRC,
			'cache_minutes' => 15,
			'limit'         => 8,
			'title'         => '',
			'font'          => 'theme', // theme = písmo témy Newspaper, figtree = písmo bloku
			'live'          => 1,       // tlačidlo spustí živé hľadanie na momondo a Ryanair
			'live_minutes'  => 10,      // výsledok živého hľadania platí X minút
			'autoload'      => 1,       // aktuálne ceny sa načítajú pri každom otvorení stránky
			'aff'           => array(), // partnerské odkazy podľa spoločnosti (momondo, ryanair, wizzair, pegasus, default)
			'tp_marker'     => '',      // Travelpayouts: ID partnera (marker) – v šablónach ako {marker}
			'tp_trs'        => '',      // Travelpayouts: ID projektu (trs) – v šablónach ako {trs}
		);
	}

	/** Spoločnosti, pre ktoré sa dá zadať partnerský odkaz. */
	public static function aff_keys() {
		return array(
			'wizzair'  => 'Wizz Air',
			'ryanair'  => 'Ryanair',
			'pegasus'  => 'Pegasus',
			'momondo'  => 'momondo',
			'default'  => 'Ostatné (ak nie je zadaná konkrétna spoločnosť)',
		);
	}

	/**
	 * Šablóny partnerských odkazov s doplnenými ID z Travelpayouts ({marker}, {trs}).
	 * Šablóna, ktorá ID potrebuje a nie je zadané, sa vynechá (aby v odkaze nezostalo „{marker}“).
	 */
	public static function affiliate() {
		$aff = self::get( 'aff' );
		$ids = array( '{marker}' => (string) self::get( 'tp_marker' ), '{trs}' => (string) self::get( 'tp_trs' ) );
		$out = array();
		foreach ( is_array( $aff ) ? $aff : array() as $k => $tpl ) {
			foreach ( $ids as $token => $value ) {
				if ( false !== strpos( $tpl, $token ) ) {
					if ( '' === $value ) {
						continue 2;
					}
					$tpl = str_replace( $token, $value, $tpl );
				}
			}
			$out[ $k ] = $tpl;
		}
		return $out;
	}

	public static function get( $key ) {
		$opts = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
		return isset( $opts[ $key ] ) ? $opts[ $key ] : null;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_post_lacne_letenky_refresh', array( __CLASS__, 'refresh' ) );
	}

	public static function menu() {
		add_options_page( 'Lacné letenky', 'Lacné letenky', 'manage_options', 'lacne-letenky', array( __CLASS__, 'page' ) );
	}

	public static function register() {
		register_setting(
			'lacne_letenky',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}

	public static function sanitize( $in ) {
		$d   = self::defaults();
		$out = array(
			'src'           => isset( $in['src'] ) && wp_http_validate_url( $in['src'] ) ? esc_url_raw( trim( $in['src'] ) ) : $d['src'],
			'cache_minutes' => isset( $in['cache_minutes'] ) ? max( 5, min( 240, (int) $in['cache_minutes'] ) ) : $d['cache_minutes'],
			'limit'         => isset( $in['limit'] ) ? max( 1, min( 24, (int) $in['limit'] ) ) : $d['limit'],
			'title'         => isset( $in['title'] ) ? sanitize_text_field( $in['title'] ) : '',
			'font'          => isset( $in['font'] ) && 'figtree' === $in['font'] ? 'figtree' : 'theme',
			'live'          => empty( $in['live'] ) ? 0 : 1,
			'autoload'      => empty( $in['autoload'] ) ? 0 : 1,
			'live_minutes'  => isset( $in['live_minutes'] ) ? max( 5, min( 120, (int) $in['live_minutes'] ) ) : $d['live_minutes'],
		);
		// ID z Travelpayouts sú čísla; iné znaky zahodíme
		$out['tp_marker'] = substr( preg_replace( '/\D+/', '', isset( $in['tp_marker'] ) ? (string) $in['tp_marker'] : '' ), 0, 12 );
		$out['tp_trs']    = substr( preg_replace( '/\D+/', '', isset( $in['tp_trs'] ) ? (string) $in['tp_trs'] : '' ), 0, 12 );
		$out['aff'] = array();
		foreach ( self::aff_keys() as $k => $label ) {
			$v = isset( $in['aff'][ $k ] ) ? trim( (string) $in['aff'][ $k ] ) : '';
			// šablóna musí byť https odkaz a použiť údaje o lete: {url}, {url_enc}, {origin} alebo {dest}
			if ( preg_match( '#^https://[^\s<>"\']+$#', $v ) && preg_match( '/\{(url|url_enc|origin|dest)\}/', $v ) ) {
				$out['aff'][ $k ] = $v;
			}
		}
		Lacne_Letenky_Data::flush();
		return $out;
	}

	public static function refresh() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Nemáte oprávnenie.', 'lacne-letenky' ) );
		}
		check_admin_referer( 'lacne_letenky_refresh' );
		Lacne_Letenky_Data::flush();
		Lacne_Letenky_Data::get( true );
		wp_safe_redirect( admin_url( 'options-general.php?page=lacne-letenky&refreshed=1' ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o      = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );
		$status = get_option( Lacne_Letenky_Data::STATUS_KEY );
		$data   = get_option( Lacne_Letenky_Data::BACKUP_KEY );
		?>
		<div class="wrap">
			<h1>Lacné letenky VIE · BTS</h1>

			<?php if ( isset( $_GET['refreshed'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
				<div class="notice notice-info is-dismissible"><p>Ceny boli znova načítané zo zdroja.</p></div>
			<?php endif; ?>

			<h2>Ako pridať blok na stránku</h2>
			<ul style="list-style:disc;padding-left:20px">
				<li><strong>tagDiv Composer (téma Newspaper):</strong> v zozname prvkov nájdite <em>Lacné letenky</em>. Ak ho tam nevidíte, pridajte prvok <em>Column text</em> a vložte doň shortcode nižšie.</li>
				<li><strong>Editor blokov (Gutenberg):</strong> pridajte blok <em>Lacné letenky</em>.</li>
				<li><strong>Shortcode kdekoľvek:</strong> <code>[lacne_letenky]</code>, prípadne <code>[lacne_letenky limit="12" title="Kam lacno z Viedne"]</code></li>
				<li><strong>Bočný panel:</strong> Vzhľad → Widgety → <em>Lacné letenky</em>.</li>
			</ul>

			<?php if ( is_array( $status ) && ! $status['ok'] ) : ?>
				<div class="notice notice-error"><p><strong>Ceny sa nepodarilo načítať zo zdroja</strong> (<?php echo esc_html( $status['message'] ); ?>).
				<?php if ( false !== strpos( $status['message'], '404' ) ) : ?>
					Súbor s cenami na tejto adrese neexistuje. Ak používate predvolenú adresu, ceny sa na GitHube objavia až po zlúčení zmien do predvolenej vetvy repozitára – dovtedy môžete nižšie zadať adresu súboru z inej vetvy.
				<?php endif; ?></p></div>
			<?php endif; ?>

			<h2>Stav cien</h2>
			<table class="widefat striped" style="max-width:760px">
				<tbody>
					<tr><th style="width:220px">Posledné hľadanie letov</th><td><?php echo is_array( $data ) && ! empty( $data['updatedAt'] ) ? esc_html( wp_date( 'j. n. Y H:i', strtotime( $data['updatedAt'] ) ) ) : '—'; ?></td></tr>
					<tr><th>Počet ponúk</th><td><?php echo is_array( $data ) && isset( $data['deals'] ) ? (int) count( $data['deals'] ) : '—'; ?></td></tr>
					<tr><th>Posledné živé hľadanie</th><td>
						<?php
						$ls = get_option( 'lacne_letenky_live_status' );
						echo is_array( $ls ) ? esc_html( wp_date( 'j. n. Y H:i', $ls['time'] ) . ' – ' . ( $ls['ok'] ? 'OK, ' : 'chyba: ' ) . $ls['message'] ) : '—';
						?>
					</td></tr>
					<tr><th>Počasie v destináciách</th><td>
						<?php
						$ws = get_option( Lacne_Letenky_Weather::STATUS );
						echo is_array( $ws ) ? esc_html( wp_date( 'j. n. Y H:i', $ws['time'] ) . ' – ' . ( $ws['ok'] ? 'OK, ' : 'chyba: ' ) . $ws['message'] ) : '—';
						$shown = 0;
						$all   = 0;
						if ( is_array( $data ) ) {
							$list = isset( $data['deals'] ) && is_array( $data['deals'] ) ? $data['deals'] : array();
							foreach ( isset( $data['watch'] ) && is_array( $data['watch'] ) ? $data['watch'] : array() as $w ) {
								if ( ! empty( $w['deal'] ) ) {
									$list[] = $w['deal'];
								}
							}
							$all = count( $list );
							foreach ( $list as $d ) {
								if ( ! empty( $d['weather'] ) ) {
									$shown++;
								}
							}
						}
						echo $all ? esc_html( sprintf( ' · počasie má %d z %d aktuálnych ponúk', $shown, $all ) ) : '';
						?>
					</td></tr>
					<tr><th>Posledné načítanie zdroja</th><td>
						<?php
						if ( is_array( $status ) ) {
							echo esc_html( wp_date( 'j. n. Y H:i', $status['time'] ) . ' – ' . ( $status['ok'] ? 'OK, ' : 'chyba: ' ) . $status['message'] );
						} else {
							echo '—';
						}
						?>
					</td></tr>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px">
				<input type="hidden" name="action" value="lacne_letenky_refresh">
				<?php wp_nonce_field( 'lacne_letenky_refresh' ); ?>
				<?php submit_button( 'Načítať ceny teraz', 'secondary', 'submit', false ); ?>
			</form>

			<h2>Nastavenia</h2>
			<form method="post" action="options.php">
				<?php settings_fields( 'lacne_letenky' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="ll-src">Zdroj dát (deals.json)</label></th>
						<td><input id="ll-src" type="url" class="large-text code" name="<?php echo esc_attr( self::OPTION ); ?>[src]" value="<?php echo esc_attr( $o['src'] ); ?>">
						<p class="description">Súbor, ktorý 3× denne aktualizuje GitHub Actions (momondo, Ryanair, Wizz Air).</p></td>
					</tr>
					<tr>
						<th scope="row"><label for="ll-cache">Obnoviť zo zdroja každých</label></th>
						<td><input id="ll-cache" type="number" min="5" max="240" name="<?php echo esc_attr( self::OPTION ); ?>[cache_minutes]" value="<?php echo esc_attr( $o['cache_minutes'] ); ?>"> minút</td>
					</tr>
					<tr>
						<th scope="row"><label for="ll-limit">Počet kariet</label></th>
						<td><input id="ll-limit" type="number" min="1" max="24" name="<?php echo esc_attr( self::OPTION ); ?>[limit]" value="<?php echo esc_attr( $o['limit'] ); ?>">
						<p class="description">Okrem veľkej karty Bangkoku. Dubaj a Abu Dhabí sú vždy medzi nimi.</p></td>
					</tr>
					<tr>
						<th scope="row"><label for="ll-title">Nadpis</label></th>
						<td><input id="ll-title" type="text" class="regular-text" placeholder="bez nadpisu" name="<?php echo esc_attr( self::OPTION ); ?>[title]" value="<?php echo esc_attr( $o['title'] ); ?>">
						<p class="description">Voliteľné. Prázdne = blok začne rovno ponukami.</p></td>
					</tr>
					<tr>
						<th scope="row">Živé hľadanie</th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[live]" value="1" <?php checked( ! empty( $o['live'] ) ); ?>> tlačidlo „Vyhľadaj aktuálne lacné letenky“ hľadá hneď na momondo a Ryanair</label>
							<p><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[autoload]" value="1" <?php checked( ! empty( $o['autoload'] ) ); ?>> aktuálne ceny načítať pri každom otvorení stránky</label></p>
							<p><label>Výsledok platí <input type="number" min="5" max="120" class="small-text" name="<?php echo esc_attr( self::OPTION ); ?>[live_minutes]" value="<?php echo esc_attr( $o['live_minutes'] ); ?>"> minút</label></p>
							<p class="description">Kliknutia v tomto čase dostanú výsledok spred chvíle, aby návštevníci nezahltili zdroje. Ceny Wizz Air sa berú z aktualizácie na GitHube.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Partnerské odkazy (provízia)</th>
						<td>
							<p><label for="ll-tp-marker"><strong>Travelpayouts ID (marker)</strong></label><br>
							<input id="ll-tp-marker" type="text" inputmode="numeric" class="regular-text" placeholder="napr. 123456" name="<?php echo esc_attr( self::OPTION ); ?>[tp_marker]" value="<?php echo esc_attr( $o['tp_marker'] ); ?>">
							&nbsp; <label for="ll-tp-trs"><strong>ID projektu (trs)</strong></label>
							<input id="ll-tp-trs" type="text" inputmode="numeric" class="small-text" placeholder="voliteľné" name="<?php echo esc_attr( self::OPTION ); ?>[tp_trs]" value="<?php echo esc_attr( $o['tp_trs'] ); ?>"></p>
							<p class="description">Zadaj raz a v šablónach nižšie použi <code>{marker}</code> a <code>{trs}</code>. Šablóna, ktorá ich potrebuje, sa bez zadaného ID nepoužije. API kľúč (token) sem nepíš.</p>
							<?php foreach ( self::aff_keys() as $k => $label ) : ?>
								<p><label for="ll-aff-<?php echo esc_attr( $k ); ?>"><strong><?php echo esc_html( $label ); ?></strong></label><br>
								<input id="ll-aff-<?php echo esc_attr( $k ); ?>" type="url" class="large-text code" placeholder="https://… {url_enc}" name="<?php echo esc_attr( self::OPTION ); ?>[aff][<?php echo esc_attr( $k ); ?>]" value="<?php echo esc_attr( isset( $o['aff'][ $k ] ) ? $o['aff'][ $k ] : '' ); ?>"></p>
							<?php endforeach; ?>
							<p class="description">Voliteľné. Vlož partnerský odkaz zo svojej affiliate siete (Travelpayouts, Awin, …). Tam, kde sa má vložiť pôvodný odkaz na let, napíš <code>{url_enc}</code> (zakódovaný) alebo <code>{url}</code>. Odkaz môžeš zostaviť aj z trasy a dátumu: <code>{origin}</code>, <code>{dest}</code>, <code>{depart}</code>, <code>{return}</code> (dátumy ako RRRR-MM-DD). Prázdne pole = odkaz ide priamo na spoločnosť. Odkazy dostanú <code>rel="sponsored nofollow"</code> a v pätičke bloku sa objaví oznam o partnerských odkazoch.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Písmo</th>
						<td>
							<label><input type="radio" name="<?php echo esc_attr( self::OPTION ); ?>[font]" value="theme" <?php checked( $o['font'], 'theme' ); ?>> podľa témy webu (odporúčané pre Newspaper)</label><br>
							<label><input type="radio" name="<?php echo esc_attr( self::OPTION ); ?>[font]" value="figtree" <?php checked( $o['font'], 'figtree' ); ?>> Figtree (Google Fonts)</label>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}
