<?php
/**
 * Načítanie cien: stiahne deals.json zo zdroja, uloží do cache a sprístupní cez REST API
 * (tlačidlo „Vyhľadaj aktuálne lacné letenky“ sa pýta na /wp-json/lacne-letenky/v1/deals).
 */

defined( 'ABSPATH' ) || exit;

class Lacne_Letenky_Data {

	const CACHE_KEY  = 'lacne_letenky_data';
	const BACKUP_KEY = 'lacne_letenky_last_good';
	const STATUS_KEY = 'lacne_letenky_status';
	const FAIL_KEY   = 'lacne_letenky_fail';

	/** Dáta na zobrazenie: novšie z (a) aktualizácie na GitHube, (b) posledného živého hľadania. */
	public static function get( $force = false ) {
		return Lacne_Letenky_Live::overlay( self::get_base( $force ) );
	}

	/** Dáta z GitHubu: z cache, inak zo zdroja; keď zdroj zlyhá, posledné úspešne načítané. */
	public static function get_base( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
			// Zdroj pred chvíľou zlyhal – nečakáme na neho pri každom zobrazení stránky.
			if ( get_transient( self::FAIL_KEY ) ) {
				return null;
			}
		}

		$data = self::fetch();
		if ( is_array( $data ) ) {
			$minutes = max( 5, (int) Lacne_Letenky_Settings::get( 'cache_minutes' ) );
			set_transient( self::CACHE_KEY, $data, $minutes * MINUTE_IN_SECONDS );
			update_option( self::BACKUP_KEY, $data, false );
			return $data;
		}

		// Zdroj je nedostupný – aby web neostal bez ponúk, použijeme poslednú úspešnú kópiu
		// a skúsime to znova o 5 minút. Blok sám skryje ponuky staršie ako 36 hodín.
		$backup = get_option( self::BACKUP_KEY );
		if ( is_array( $backup ) ) {
			set_transient( self::CACHE_KEY, $backup, 5 * MINUTE_IN_SECONDS );
			return $backup;
		}
		set_transient( self::FAIL_KEY, 1, 5 * MINUTE_IN_SECONDS );
		return null;
	}

	private static function fetch() {
		$src     = Lacne_Letenky_Settings::get( 'src' );
		$sources = array( $src );
		if ( defined( 'LACNE_LETENKY_FALLBACK_SRC' ) && LACNE_LETENKY_FALLBACK_SRC !== $src && LACNE_LETENKY_DEFAULT_SRC === $src ) {
			$sources[] = LACNE_LETENKY_FALLBACK_SRC; // predvolený zdroj ešte nemá dáta → skús záložný
		}
		$res = null;
		foreach ( $sources as $try ) {
			$res = wp_remote_get(
				add_query_arg( 't', time(), $try ),
				array(
					'timeout' => 10,
					'headers' => array( 'Accept' => 'application/json' ),
				)
			);
			if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
				break;
			}
		}

		$status = array( 'time' => time(), 'ok' => false, 'message' => '' );
		if ( is_wp_error( $res ) ) {
			$status['message'] = $res->get_error_message();
		} elseif ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			$status['message'] = 'HTTP ' . wp_remote_retrieve_response_code( $res );
		} else {
			$data = json_decode( wp_remote_retrieve_body( $res ), true );
			if ( is_array( $data ) && isset( $data['deals'] ) && is_array( $data['deals'] ) ) {
				$status['ok']      = true;
				$status['message'] = sprintf( '%d ponúk', count( $data['deals'] ) );
				update_option( self::STATUS_KEY, $status, false );
				return $data;
			}
			$status['message'] = 'Súbor nemá očakávaný formát (chýba "deals").';
		}
		update_option( self::STATUS_KEY, $status, false );
		return null;
	}

	public static function flush() {
		delete_transient( self::CACHE_KEY );
		delete_transient( self::FAIL_KEY );
		Lacne_Letenky_Weather::flush();
	}

	public static function register_rest() {
		register_rest_route(
			'lacne-letenky/v1',
			'/deals',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'args'                => array( 'refresh' => array( 'required' => false ) ),
				'callback'            => function ( $request ) {
					// Tlačidlo „Vyhľadaj aktuálne lacné letenky“ posiela refresh=1 → živé hľadanie.
					if ( $request->get_param( 'refresh' ) && Lacne_Letenky_Settings::get( 'live' ) ) {
						$data = Lacne_Letenky_Live::search( self::get_base() );
					} else {
						$data = self::get();
					}
					if ( ! is_array( $data ) ) {
						// Zdroj zatiaľ nemá dáta (napr. súbor ešte neexistuje) – blok ukáže
						// „Ponuky sa pripravujú“ namiesto chyby. Príčina je v Nastavenia → Lacné letenky.
						$data = array( 'updatedAt' => null, 'deals' => array(), 'watch' => array(), 'unavailable' => true );
					}
					$res = rest_ensure_response( $data );
					$res->header( 'Cache-Control', 'no-cache, max-age=0' );
					return $res;
				},
			)
		);
	}

	public static function rest_url() {
		return rest_url( 'lacne-letenky/v1/deals' );
	}
}
